-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 30 Ara 2023, 23:07:14
-- Sunucu sürümü: 5.7.40
-- PHP Sürümü: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `canberk`
--

DELIMITER $$
--
-- Yordamlar
--
DROP PROCEDURE IF EXISTS `akdeniz_fiyat`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `akdeniz_fiyat` ()   SELECT MIN(araclar.fiyat) AS "min_fiyat", MAX(araclar.fiyat) AS "max_fiyat"
FROM araclar,bolge
WHERE araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=5
AND araclar.satis_adet>2539$$

DROP PROCEDURE IF EXISTS `akdeniz_markalar`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `akdeniz_markalar` ()   SELECT marka.marka_ad, model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=5
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `akdeniz_model`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `akdeniz_model` ()   SELECT model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=5
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `akdeniz_motorhacim`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `akdeniz_motorhacim` ()   SELECT motorhacim.hacim_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, motorhacim
WHERE motorhacim.hacim_id=araclar.hacim_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=5
AND araclar.satis_adet>2539
GROUP BY motorhacim.hacim_id$$

DROP PROCEDURE IF EXISTS `akdeniz_tarz`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `akdeniz_tarz` ()   SELECT tarz.tarz_ad, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, tarz
WHERE tarz.tarz_id=araclar.tarz_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=5
AND araclar.satis_adet>2539
GROUP BY tarz.tarz_id$$

DROP PROCEDURE IF EXISTS `akdeniz_vites`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `akdeniz_vites` ()   SELECT vites.vites_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, vites
WHERE vites.vites_id=araclar.vites_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=5
AND araclar.satis_adet>2539
GROUP BY vites.vites_id$$

DROP PROCEDURE IF EXISTS `dogu_anadolu_fiyat`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `dogu_anadolu_fiyat` ()   SELECT MIN(araclar.fiyat) AS 'min_fiyat', MAX(araclar.fiyat) AS 'max_fiyat'
FROM araclar,bolge
WHERE araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=6
AND araclar.satis_adet>2485$$

DROP PROCEDURE IF EXISTS `dogu_anadolu_markalar`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `dogu_anadolu_markalar` ()   SELECT marka.marka_ad, model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=6
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `dogu_anadolu_model`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `dogu_anadolu_model` ()   SELECT model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=6
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `dogu_anadolu_motorhacim`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `dogu_anadolu_motorhacim` ()   SELECT motorhacim.hacim_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, motorhacim
WHERE motorhacim.hacim_id=araclar.hacim_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=6
AND araclar.satis_adet>2485
GROUP BY motorhacim.hacim_id$$

DROP PROCEDURE IF EXISTS `dogu_anadolu_tarz`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `dogu_anadolu_tarz` ()   SELECT tarz.tarz_ad, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, tarz
WHERE tarz.tarz_id=araclar.tarz_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=6
AND araclar.satis_adet>2485
GROUP BY tarz.tarz_id$$

DROP PROCEDURE IF EXISTS `dogu_anadolu_vites`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `dogu_anadolu_vites` ()   SELECT vites.vites_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, vites
WHERE vites.vites_id=araclar.vites_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=6
AND araclar.satis_adet>2485
GROUP BY vites.vites_id$$

DROP PROCEDURE IF EXISTS `ege_fiyat`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ege_fiyat` ()   SELECT MIN(araclar.fiyat) AS 'min_fiyat', MAX(araclar.fiyat) AS 'max_fiyat'
FROM araclar,bolge
WHERE araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=3
AND araclar.satis_adet>4234$$

DROP PROCEDURE IF EXISTS `ege_markalar`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ege_markalar` ()   SELECT marka.marka_ad, model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=3
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `ege_model`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ege_model` ()   SELECT model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=3
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `ege_motorhacim`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ege_motorhacim` ()   SELECT motorhacim.hacim_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, motorhacim
WHERE motorhacim.hacim_id=araclar.hacim_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=3
AND araclar.satis_adet>4234
GROUP BY motorhacim.hacim_id$$

DROP PROCEDURE IF EXISTS `ege_tarz`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ege_tarz` ()   SELECT tarz.tarz_ad, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, tarz
WHERE tarz.tarz_id=araclar.tarz_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=3
AND araclar.satis_adet>4234
GROUP BY tarz.tarz_id$$

DROP PROCEDURE IF EXISTS `ege_vites`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ege_vites` ()   SELECT vites.vites_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, vites
WHERE vites.vites_id=araclar.vites_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=3
AND araclar.satis_adet>4234
GROUP BY vites.vites_id$$

DROP PROCEDURE IF EXISTS `guneydogu_anadolu_fiyat`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `guneydogu_anadolu_fiyat` ()   SELECT MIN(araclar.fiyat) AS 'min_fiyat', MAX(araclar.fiyat) AS 'max_fiyat'
FROM araclar,bolge
WHERE araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=7
AND araclar.satis_adet>2455$$

DROP PROCEDURE IF EXISTS `guneydogu_anadolu_markalar`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `guneydogu_anadolu_markalar` ()   SELECT marka.marka_ad, model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=7
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `guneydogu_anadolu_model`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `guneydogu_anadolu_model` ()   SELECT model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=7
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `guneydogu_anadolu_motorhacim`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `guneydogu_anadolu_motorhacim` ()   SELECT motorhacim.hacim_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, motorhacim
WHERE motorhacim.hacim_id=araclar.hacim_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=7
AND araclar.satis_adet>2455
GROUP BY motorhacim.hacim_id$$

DROP PROCEDURE IF EXISTS `guneydogu_anadolu_tarz`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `guneydogu_anadolu_tarz` ()   SELECT tarz.tarz_ad, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, tarz
WHERE tarz.tarz_id=araclar.tarz_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=7
AND araclar.satis_adet>2455
GROUP BY tarz.tarz_id$$

DROP PROCEDURE IF EXISTS `guneydogu_anadolu_vites`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `guneydogu_anadolu_vites` ()   SELECT vites.vites_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, vites
WHERE vites.vites_id=araclar.vites_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=7
AND araclar.satis_adet>2455
GROUP BY vites.vites_id$$

DROP PROCEDURE IF EXISTS `ic_anadolu_fiyat`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ic_anadolu_fiyat` ()   SELECT MIN(araclar.fiyat) AS 'min_fiyat', MAX(araclar.fiyat) AS 'max_fiyat'
FROM araclar,bolge
WHERE araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=4
AND araclar.satis_adet>4779$$

DROP PROCEDURE IF EXISTS `ic_anadolu_markalar`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ic_anadolu_markalar` ()   SELECT marka.marka_ad, model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=4
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `ic_anadolu_model`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ic_anadolu_model` ()   SELECT model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=4
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `ic_anadolu_motorhacim`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ic_anadolu_motorhacim` ()   SELECT motorhacim.hacim_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, motorhacim
WHERE motorhacim.hacim_id=araclar.hacim_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=4
AND araclar.satis_adet>4779
GROUP BY motorhacim.hacim_id$$

DROP PROCEDURE IF EXISTS `ic_anadolu_tarz`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ic_anadolu_tarz` ()   SELECT tarz.tarz_ad, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, tarz
WHERE tarz.tarz_id=araclar.tarz_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=4
AND araclar.satis_adet>4779
GROUP BY tarz.tarz_id$$

DROP PROCEDURE IF EXISTS `ic_anadolu_vites`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `ic_anadolu_vites` ()   SELECT vites.vites_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, vites
WHERE vites.vites_id=araclar.vites_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=4
AND araclar.satis_adet>4779
GROUP BY vites.vites_id$$

DROP PROCEDURE IF EXISTS `karadeniz_fiyat`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `karadeniz_fiyat` ()   SELECT MIN(araclar.fiyat) AS 'min_fiyat', MAX(araclar.fiyat) AS 'max_fiyat'
FROM araclar,bolge
WHERE araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=2
AND araclar.satis_adet>5219$$

DROP PROCEDURE IF EXISTS `karadeniz_markalar`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `karadeniz_markalar` ()   SELECT marka.marka_ad, model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=2
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `karadeniz_model`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `karadeniz_model` ()   SELECT model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=2
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `karadeniz_motorhacim`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `karadeniz_motorhacim` ()   SELECT motorhacim.hacim_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, motorhacim
WHERE motorhacim.hacim_id=araclar.hacim_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=2
AND araclar.satis_adet>5219
GROUP BY motorhacim.hacim_id$$

DROP PROCEDURE IF EXISTS `karadeniz_tarz`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `karadeniz_tarz` ()   SELECT tarz.tarz_ad, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, tarz
WHERE tarz.tarz_id=araclar.tarz_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=2
AND araclar.satis_adet>5219
GROUP BY tarz.tarz_id$$

DROP PROCEDURE IF EXISTS `karadeniz_vites`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `karadeniz_vites` ()   SELECT vites.vites_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, vites
WHERE vites.vites_id=araclar.vites_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=2
AND araclar.satis_adet>5219
GROUP BY vites.vites_id$$

DROP PROCEDURE IF EXISTS `marmara_fiyat`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `marmara_fiyat` ()   SELECT MIN(araclar.fiyat) AS 'min_fiyat', MAX(araclar.fiyat) AS 'max_fiyat'
FROM araclar,bolge 
WHERE araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=1
AND araclar.satis_adet>7568$$

DROP PROCEDURE IF EXISTS `marmara_markalar`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `marmara_markalar` ()   SELECT marka.marka_ad, model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=1
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `marmara_model`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `marmara_model` ()   SELECT model.model_ad, araclar.satis_adet
FROM marka, model, araclar, bolge
WHERE marka.marka_id=model.marka_id 
AND araclar.marka_id=marka.marka_id
AND araclar.model_id=model.model_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=1
ORDER BY araclar.satis_adet DESC
LIMIT 5$$

DROP PROCEDURE IF EXISTS `marmara_motorhacim`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `marmara_motorhacim` ()   SELECT motorhacim.hacim_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, motorhacim
WHERE motorhacim.hacim_id=araclar.hacim_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=1
AND araclar.satis_adet>7568
GROUP BY motorhacim.hacim_id$$

DROP PROCEDURE IF EXISTS `marmara_tarz`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `marmara_tarz` ()   SELECT tarz.tarz_ad, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, tarz
WHERE tarz.tarz_id=araclar.tarz_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=1
AND araclar.satis_adet>7568
GROUP BY tarz.tarz_id$$

DROP PROCEDURE IF EXISTS `marmara_vites`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `marmara_vites` ()   SELECT vites.vites_tur, SUM(araclar.satis_adet) AS 'satis_adet'
FROM araclar, bolge, vites
WHERE vites.vites_id=araclar.vites_id
AND araclar.bolge_id=bolge.bolge_id
AND bolge.bolge_id=1
AND araclar.satis_adet>7568
GROUP BY vites.vites_id$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `araclar`
--

DROP TABLE IF EXISTS `araclar`;
CREATE TABLE IF NOT EXISTS `araclar` (
  `aracSatisID` int(11) NOT NULL AUTO_INCREMENT,
  `bolge_id` int(11) NOT NULL,
  `marka_id` int(11) DEFAULT NULL,
  `model_id` int(11) DEFAULT NULL,
  `tarz_id` int(11) NOT NULL,
  `hacim_id` int(11) NOT NULL,
  `vites_id` int(11) NOT NULL,
  `fiyat` int(11) NOT NULL,
  `satis_adet` int(11) NOT NULL,
  PRIMARY KEY (`aracSatisID`),
  KEY `bolge_id` (`bolge_id`),
  KEY `marka_id` (`marka_id`),
  KEY `model_id` (`model_id`),
  KEY `hacim_id` (`hacim_id`),
  KEY `tarz_id` (`tarz_id`),
  KEY `vites_id` (`vites_id`)
) ENGINE=InnoDB AUTO_INCREMENT=311 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `araclar`
--

INSERT INTO `araclar` (`aracSatisID`, `bolge_id`, `marka_id`, `model_id`, `tarz_id`, `hacim_id`, `vites_id`, `fiyat`, `satis_adet`) VALUES
(1, 1, 1, 1, 1, 7, 2, 1597015, 627),
(2, 1, 1, 2, 1, 10, 2, 3179892, 476),
(3, 1, 2, 4, 1, 8, 1, 5301900, 712),
(4, 1, 2, 3, 1, 8, 2, 3332700, 540),
(5, 1, 3, 5, 1, 8, 2, 1400000, 1538),
(6, 1, 3, 6, 1, 8, 2, 1450000, 1602),
(7, 1, 3, 7, 1, 8, 2, 1640000, 1780),
(8, 1, 4, 8, 1, 4, 2, 1256700, 1026),
(9, 1, 4, 9, 1, 1, 2, 390000, 400),
(10, 1, 4, 10, 2, 7, 1, 886100, 420),
(11, 1, 5, 11, 1, 7, 1, 1095000, 3260),
(12, 1, 5, 12, 1, 2, 1, 1105000, 1504),
(13, 1, 5, 13, 1, 2, 2, 873900, 2000),
(14, 1, 6, 14, 1, 5, 1, 973900, 12700),
(15, 1, 6, 15, 1, 8, 2, 1260900, 7600),
(16, 1, 6, 16, 2, 5, 1, 748900, 11009),
(17, 1, 7, 17, 1, 7, 2, 1588300, 1795),
(18, 1, 7, 18, 2, 7, 1, 945600, 1350),
(19, 1, 8, 19, 1, 7, 2, 1045000, 880),
(20, 1, 8, 20, 1, 7, 2, 1573100, 595),
(21, 1, 9, 21, 1, 6, 2, 1020000, 2300),
(22, 1, 10, 22, 1, 2, 2, 1080000, 650),
(23, 1, 10, 23, 1, 2, 2, 800000, 500),
(24, 1, 11, 24, 1, 8, 2, 3570000, 700),
(25, 1, 11, 25, 1, 10, 2, 3761000, 550),
(26, 1, 12, 26, 1, 5, 2, 1783800, 1350),
(27, 1, 13, 27, 1, 4, 2, 1095900, 7800),
(28, 1, 13, 28, 1, 4, 2, 1433900, 1600),
(29, 1, 13, 29, 2, 7, 1, 819900, 1982),
(30, 1, 14, 30, 1, 7, 2, 1881000, 2197),
(31, 1, 14, 31, 1, 4, 2, 1540000, 1960),
(32, 1, 14, 32, 2, 7, 1, 1005000, 1802),
(33, 1, 15, 33, 1, 2, 2, 1041900, 7200),
(34, 1, 15, 34, 1, 5, 2, 1244900, 7569),
(35, 1, 15, 35, 1, 2, 2, 940000, 5800),
(36, 1, 15, 36, 2, 7, 1, 863000, 4600),
(37, 1, 16, 37, 1, 2, 2, 1020000, 328),
(38, 1, 17, 38, 1, 7, 2, 2189000, 850),
(39, 1, 18, 39, 1, 7, 2, 1305000, 2420),
(40, 1, 19, 40, 1, 7, 2, 1779400, 2520),
(41, 1, 19, 41, 2, 10, 2, 1185000, 1400),
(42, 1, 19, 42, 1, 10, 2, 2313000, 1692),
(43, 1, 20, 43, 1, 7, 2, 1339760, 468),
(44, 1, 20, 44, 1, 10, 2, 1884930, 526),
(45, 2, 1, 1, 1, 7, 2, 1597015, 750),
(46, 2, 1, 2, 1, 10, 2, 3179892, 700),
(47, 2, 2, 3, 1, 8, 1, 5301900, 390),
(48, 2, 2, 4, 1, 8, 2, 3332700, 320),
(49, 2, 3, 5, 1, 8, 2, 1400000, 1500),
(50, 2, 3, 6, 1, 8, 2, 1450000, 2100),
(51, 2, 3, 7, 1, 8, 2, 1640000, 7300),
(52, 2, 4, 8, 1, 4, 2, 1256700, 1300),
(53, 2, 4, 9, 1, 1, 2, 390000, 120),
(54, 2, 4, 10, 2, 7, 1, 886100, 850),
(55, 2, 5, 11, 1, 7, 1, 1095000, 5768),
(56, 2, 5, 12, 1, 2, 1, 1105000, 1057),
(57, 2, 5, 13, 1, 2, 2, 873900, 1790),
(58, 2, 6, 14, 1, 5, 1, 973900, 5200),
(59, 2, 6, 15, 1, 8, 2, 1260900, 7800),
(60, 2, 6, 16, 2, 5, 1, 748900, 4800),
(61, 2, 7, 17, 1, 7, 2, 1588300, 2500),
(62, 2, 7, 18, 2, 7, 1, 945600, 3280),
(63, 2, 8, 19, 1, 7, 2, 1045000, 320),
(64, 2, 8, 20, 1, 7, 2, 1573100, 270),
(65, 2, 9, 21, 1, 6, 2, 1020000, 1320),
(66, 2, 10, 22, 1, 2, 2, 1080000, 790),
(67, 2, 10, 23, 1, 2, 2, 800000, 200),
(68, 2, 11, 24, 1, 8, 2, 3570000, 1200),
(69, 2, 11, 25, 1, 10, 2, 3761000, 400),
(70, 2, 12, 26, 1, 5, 2, 1783800, 2600),
(71, 2, 13, 27, 1, 4, 2, 1095900, 2500),
(72, 2, 13, 28, 1, 4, 2, 1433900, 1020),
(73, 2, 13, 29, 2, 7, 1, 819900, 5220),
(74, 2, 14, 30, 1, 7, 2, 1881000, 1497),
(75, 2, 14, 31, 1, 4, 2, 1540000, 1130),
(76, 2, 14, 32, 2, 7, 1, 1005000, 2689),
(77, 2, 15, 33, 1, 2, 2, 1041900, 4300),
(78, 2, 15, 34, 1, 5, 2, 1244900, 7562),
(79, 2, 15, 35, 1, 2, 2, 940000, 3800),
(80, 2, 15, 36, 2, 7, 1, 863000, 4150),
(81, 2, 16, 37, 1, 2, 2, 1020000, 557),
(82, 2, 17, 38, 1, 7, 2, 2189000, 1963),
(83, 2, 18, 39, 1, 7, 2, 1305000, 2500),
(84, 2, 19, 40, 1, 7, 2, 1779400, 1300),
(85, 2, 19, 41, 2, 10, 2, 1185000, 1200),
(86, 2, 19, 42, 1, 10, 2, 2313000, 3750),
(87, 2, 20, 43, 1, 7, 2, 1339760, 280),
(88, 2, 20, 44, 1, 10, 2, 1884930, 340),
(89, 3, 1, 1, 1, 7, 2, 1597015, 750),
(90, 3, 1, 2, 1, 10, 2, 3179892, 700),
(91, 3, 2, 3, 1, 8, 1, 5301900, 390),
(92, 3, 2, 4, 1, 8, 2, 3332700, 320),
(93, 3, 3, 5, 1, 8, 2, 1400000, 1500),
(94, 3, 3, 6, 1, 8, 2, 1450000, 2100),
(95, 3, 3, 7, 1, 8, 2, 1640000, 3230),
(96, 3, 4, 8, 1, 4, 2, 1256700, 1300),
(97, 3, 4, 9, 1, 1, 2, 390000, 120),
(98, 3, 4, 10, 2, 7, 1, 886100, 850),
(99, 3, 5, 11, 1, 7, 1, 1095000, 4220),
(100, 3, 5, 12, 1, 2, 1, 1105000, 1057),
(101, 3, 5, 13, 1, 2, 2, 873900, 1790),
(102, 3, 6, 14, 1, 5, 1, 973900, 4050),
(103, 3, 6, 15, 1, 8, 2, 1260900, 4000),
(104, 3, 6, 16, 2, 5, 1, 748900, 4100),
(105, 3, 7, 17, 1, 7, 2, 1588300, 2500),
(106, 3, 7, 18, 2, 7, 1, 945600, 3280),
(107, 3, 8, 19, 1, 7, 2, 1045000, 320),
(108, 3, 8, 20, 1, 7, 2, 1573100, 270),
(109, 3, 9, 21, 1, 6, 2, 1020000, 1320),
(110, 3, 10, 22, 1, 2, 2, 1080000, 790),
(111, 3, 10, 23, 1, 2, 2, 800000, 4398),
(112, 3, 11, 24, 1, 8, 2, 3570000, 1200),
(113, 3, 11, 25, 1, 10, 2, 3761000, 400),
(114, 3, 12, 26, 1, 5, 2, 1783800, 4600),
(115, 3, 13, 27, 1, 4, 2, 1095900, 2500),
(116, 3, 13, 28, 1, 4, 2, 1433900, 1020),
(117, 3, 13, 29, 2, 7, 1, 819900, 2150),
(118, 3, 14, 30, 1, 7, 2, 1881000, 1497),
(119, 3, 14, 31, 1, 4, 2, 1540000, 1130),
(120, 3, 14, 32, 2, 7, 1, 1005000, 2689),
(121, 3, 15, 33, 1, 2, 2, 1041900, 4090),
(122, 3, 15, 34, 1, 5, 2, 1244900, 4230),
(123, 3, 15, 35, 1, 2, 2, 940000, 3800),
(124, 3, 15, 36, 2, 7, 1, 863000, 4235),
(125, 3, 16, 37, 1, 2, 2, 1020000, 4300),
(126, 3, 17, 38, 1, 7, 2, 2189000, 1963),
(127, 3, 18, 39, 1, 7, 2, 1305000, 2500),
(128, 3, 19, 40, 1, 7, 2, 1779400, 1300),
(129, 3, 19, 41, 2, 10, 2, 1185000, 1200),
(130, 3, 19, 42, 1, 10, 2, 2313000, 3750),
(131, 3, 20, 43, 1, 7, 2, 1339760, 2140),
(132, 3, 20, 44, 1, 10, 2, 1884930, 4452),
(133, 4, 1, 1, 1, 7, 2, 1597015, 750),
(134, 4, 1, 2, 1, 10, 2, 3179892, 700),
(135, 4, 2, 3, 1, 8, 1, 5301900, 390),
(136, 4, 2, 4, 1, 8, 2, 3332700, 320),
(137, 4, 3, 5, 1, 8, 2, 1400000, 1500),
(138, 4, 3, 6, 1, 8, 2, 1450000, 2100),
(139, 4, 3, 7, 1, 8, 2, 1640000, 3230),
(140, 4, 4, 8, 1, 4, 2, 1256700, 1300),
(141, 4, 4, 9, 1, 1, 2, 390000, 120),
(142, 4, 4, 10, 2, 7, 1, 886100, 4900),
(143, 4, 5, 11, 1, 7, 1, 1095000, 4220),
(144, 4, 5, 12, 1, 2, 1, 1105000, 1057),
(145, 4, 5, 13, 1, 2, 2, 873900, 4780),
(146, 4, 6, 14, 1, 5, 1, 973900, 4050),
(147, 4, 6, 15, 1, 8, 2, 1260900, 4000),
(148, 4, 6, 16, 2, 5, 1, 748900, 4300),
(149, 4, 7, 17, 1, 7, 2, 1588300, 2500),
(150, 4, 7, 18, 2, 7, 1, 945600, 3280),
(151, 4, 8, 19, 1, 7, 2, 1045000, 320),
(152, 4, 8, 20, 1, 7, 2, 1573100, 5630),
(153, 4, 9, 21, 1, 6, 2, 1020000, 1320),
(154, 4, 10, 22, 1, 2, 2, 1080000, 790),
(155, 4, 10, 23, 1, 2, 2, 800000, 4398),
(156, 4, 11, 24, 1, 8, 2, 3570000, 1200),
(157, 4, 11, 25, 1, 10, 2, 3761000, 400),
(158, 4, 12, 26, 1, 5, 2, 1783800, 4600),
(159, 4, 13, 27, 1, 4, 2, 1095900, 2500),
(160, 4, 13, 28, 1, 4, 2, 1433900, 1020),
(161, 4, 13, 29, 2, 7, 1, 819900, 2150),
(162, 4, 14, 30, 1, 7, 2, 1881000, 1497),
(163, 4, 14, 31, 1, 4, 2, 1540000, 1130),
(164, 4, 14, 32, 2, 7, 1, 1005000, 2689),
(165, 4, 15, 33, 1, 2, 2, 1041900, 4300),
(166, 4, 15, 34, 1, 5, 2, 1244900, 4230),
(167, 4, 15, 35, 1, 2, 2, 940000, 3800),
(168, 4, 15, 36, 2, 7, 1, 863000, 4150),
(169, 4, 16, 37, 1, 2, 2, 1020000, 4300),
(170, 4, 17, 38, 1, 7, 2, 2189000, 1963),
(171, 4, 18, 39, 1, 7, 2, 1305000, 5200),
(172, 4, 19, 40, 1, 7, 2, 1779400, 1300),
(173, 4, 19, 41, 2, 10, 2, 1185000, 4900),
(174, 4, 19, 42, 1, 10, 2, 2313000, 3750),
(175, 4, 20, 43, 1, 7, 2, 1339760, 2140),
(176, 4, 20, 44, 1, 10, 2, 1884930, 4452),
(177, 5, 1, 1, 1, 7, 2, 1597015, 750),
(178, 5, 1, 2, 1, 10, 2, 3179892, 700),
(179, 5, 2, 3, 1, 8, 1, 5301900, 390),
(180, 5, 2, 4, 1, 8, 2, 3332700, 3480),
(181, 5, 3, 5, 1, 8, 2, 1400000, 1500),
(182, 5, 3, 6, 1, 8, 2, 1450000, 2100),
(183, 5, 3, 7, 1, 8, 2, 1640000, 2350),
(184, 5, 4, 8, 1, 4, 2, 1256700, 1300),
(185, 5, 4, 9, 1, 1, 2, 390000, 120),
(186, 5, 4, 10, 2, 7, 1, 886100, 2400),
(187, 5, 5, 11, 1, 7, 1, 1095000, 2100),
(188, 5, 5, 12, 1, 2, 1, 1105000, 1057),
(189, 5, 5, 13, 1, 2, 2, 873900, 1995),
(190, 5, 6, 14, 1, 5, 1, 973900, 2000),
(191, 5, 6, 15, 1, 8, 2, 1260900, 2480),
(192, 5, 6, 16, 2, 5, 1, 748900, 1865),
(193, 5, 7, 17, 1, 7, 2, 1588300, 2500),
(194, 5, 7, 18, 2, 7, 1, 945600, 2540),
(195, 5, 8, 19, 1, 7, 2, 1045000, 5600),
(196, 5, 8, 20, 1, 7, 2, 1573100, 1100),
(197, 5, 9, 21, 1, 6, 2, 1020000, 3500),
(198, 5, 10, 22, 1, 2, 2, 1080000, 790),
(199, 5, 10, 23, 1, 2, 2, 800000, 1900),
(200, 5, 11, 24, 1, 8, 2, 3570000, 1200),
(201, 5, 11, 25, 1, 10, 2, 3761000, 400),
(202, 5, 12, 26, 1, 5, 2, 1783800, 1996),
(203, 5, 13, 27, 1, 4, 2, 1095900, 2100),
(204, 5, 13, 28, 1, 4, 2, 1433900, 1020),
(205, 5, 13, 29, 2, 7, 1, 819900, 2150),
(206, 5, 14, 30, 1, 7, 2, 1881000, 1497),
(207, 5, 14, 31, 1, 4, 2, 1540000, 1130),
(208, 5, 14, 32, 2, 7, 1, 1005000, 2200),
(209, 5, 15, 33, 1, 2, 2, 1041900, 1320),
(210, 5, 15, 34, 1, 5, 2, 1244900, 2198),
(211, 5, 15, 35, 1, 2, 2, 940000, 1759),
(212, 5, 15, 36, 2, 7, 1, 863000, 1750),
(213, 5, 16, 37, 1, 2, 2, 1020000, 980),
(214, 5, 17, 38, 1, 7, 2, 2189000, 1963),
(215, 5, 18, 39, 1, 7, 2, 1305000, 1400),
(216, 5, 19, 40, 1, 7, 2, 1779400, 2700),
(217, 5, 19, 41, 2, 10, 2, 1185000, 2056),
(218, 5, 19, 42, 1, 10, 2, 2313000, 1900),
(219, 5, 20, 43, 1, 7, 2, 1339760, 312),
(220, 5, 20, 44, 1, 10, 2, 1884930, 580),
(221, 6, 1, 1, 1, 7, 2, 1597015, 750),
(222, 6, 1, 2, 1, 10, 2, 3179892, 700),
(223, 6, 2, 3, 1, 8, 1, 5301900, 390),
(224, 6, 2, 4, 1, 8, 2, 3332700, 2365),
(225, 6, 3, 5, 1, 8, 2, 1400000, 1500),
(226, 6, 3, 6, 1, 8, 2, 1450000, 2100),
(227, 6, 3, 7, 1, 8, 2, 1640000, 1337),
(228, 6, 4, 8, 1, 4, 2, 1256700, 1300),
(229, 6, 4, 9, 1, 1, 2, 390000, 120),
(230, 6, 4, 10, 2, 7, 1, 886100, 2400),
(231, 6, 5, 11, 1, 7, 1, 1095000, 2100),
(232, 6, 5, 12, 1, 2, 1, 1105000, 1057),
(233, 6, 5, 13, 1, 2, 2, 873900, 2980),
(234, 6, 6, 14, 1, 5, 1, 973900, 2000),
(235, 6, 6, 15, 1, 8, 2, 1260900, 2480),
(236, 6, 6, 16, 2, 5, 1, 748900, 1865),
(237, 6, 7, 17, 1, 7, 2, 1588300, 1705),
(238, 6, 7, 18, 2, 7, 1, 945600, 2600),
(239, 6, 8, 19, 1, 7, 2, 1045000, 1860),
(240, 6, 8, 20, 1, 7, 2, 1573100, 1100),
(241, 6, 9, 21, 1, 6, 2, 1020000, 1950),
(242, 6, 10, 22, 1, 2, 2, 1080000, 790),
(243, 6, 10, 23, 1, 2, 2, 800000, 1900),
(244, 6, 11, 24, 1, 8, 2, 3570000, 1200),
(245, 6, 11, 25, 1, 10, 2, 3761000, 400),
(246, 6, 12, 26, 1, 5, 2, 1783800, 1996),
(247, 6, 13, 27, 1, 4, 2, 1095900, 2100),
(248, 6, 13, 28, 1, 4, 2, 1433900, 1020),
(249, 6, 13, 29, 2, 7, 1, 819900, 2150),
(250, 6, 14, 30, 1, 7, 2, 1881000, 1497),
(251, 6, 14, 31, 1, 4, 2, 1540000, 1130),
(252, 6, 14, 32, 2, 7, 1, 1005000, 1026),
(253, 6, 15, 33, 1, 2, 2, 1041900, 1320),
(254, 6, 15, 34, 1, 5, 2, 1244900, 2198),
(255, 6, 15, 35, 1, 2, 2, 940000, 1759),
(256, 6, 15, 36, 2, 7, 1, 863000, 2486),
(257, 6, 16, 37, 1, 2, 2, 1020000, 980),
(258, 6, 17, 38, 1, 7, 2, 2189000, 2863),
(259, 6, 18, 39, 1, 7, 2, 1305000, 3251),
(260, 6, 19, 40, 1, 7, 2, 1779400, 1600),
(261, 6, 19, 41, 2, 10, 2, 1185000, 2306),
(262, 6, 19, 42, 1, 10, 2, 2313000, 2024),
(263, 6, 20, 43, 1, 7, 2, 1339760, 312),
(264, 6, 20, 44, 1, 10, 2, 1884930, 580),
(265, 7, 1, 1, 1, 7, 2, 1597015, 750),
(266, 7, 1, 2, 1, 10, 2, 3179892, 2456),
(267, 7, 2, 3, 1, 8, 1, 5301900, 390),
(268, 7, 2, 4, 1, 8, 2, 3332700, 2365),
(269, 7, 3, 5, 1, 8, 2, 1400000, 1500),
(270, 7, 3, 6, 1, 8, 2, 1450000, 2100),
(271, 7, 3, 7, 1, 8, 2, 1640000, 1405),
(272, 7, 4, 8, 1, 4, 2, 1256700, 1300),
(273, 7, 4, 9, 1, 1, 2, 390000, 120),
(274, 7, 4, 10, 2, 7, 1, 886100, 2400),
(275, 7, 5, 11, 1, 7, 1, 1095000, 2100),
(276, 7, 5, 12, 1, 2, 1, 1105000, 1057),
(277, 7, 5, 13, 1, 2, 2, 873900, 2360),
(278, 7, 6, 14, 1, 5, 1, 973900, 2000),
(279, 7, 6, 15, 1, 8, 2, 1260900, 2400),
(280, 7, 6, 16, 2, 5, 1, 748900, 1865),
(281, 7, 7, 17, 1, 7, 2, 1588300, 2595),
(282, 7, 7, 18, 2, 7, 1, 945600, 2300),
(283, 7, 8, 19, 1, 7, 2, 1045000, 1860),
(284, 7, 8, 20, 1, 7, 2, 1573100, 1100),
(285, 7, 9, 21, 1, 6, 2, 1020000, 1950),
(286, 7, 10, 22, 1, 2, 2, 1080000, 790),
(287, 7, 10, 23, 1, 2, 2, 800000, 1900),
(288, 7, 11, 24, 1, 8, 2, 3570000, 1200),
(289, 7, 11, 25, 1, 10, 2, 3761000, 400),
(290, 7, 12, 26, 1, 5, 2, 1783800, 1996),
(291, 7, 13, 27, 1, 4, 2, 1095900, 2100),
(292, 7, 13, 28, 1, 4, 2, 1433900, 1020),
(293, 7, 13, 29, 2, 7, 1, 819900, 2150),
(294, 7, 14, 30, 1, 7, 2, 1881000, 1497),
(295, 7, 14, 31, 1, 4, 2, 1540000, 2603),
(296, 7, 14, 32, 2, 7, 1, 1005000, 2154),
(297, 7, 15, 33, 1, 2, 2, 1041900, 1320),
(298, 7, 15, 34, 1, 5, 2, 1244900, 2989),
(299, 7, 15, 35, 1, 2, 2, 940000, 1759),
(300, 7, 15, 36, 2, 7, 1, 863000, 1750),
(301, 7, 16, 37, 1, 2, 2, 1020000, 980),
(302, 7, 17, 38, 1, 7, 2, 2189000, 1707),
(303, 7, 18, 39, 1, 7, 2, 1305000, 2360),
(304, 7, 19, 40, 1, 7, 2, 1779400, 1600),
(305, 7, 19, 41, 2, 10, 2, 1185000, 2306),
(306, 7, 19, 42, 1, 10, 2, 2313000, 2900),
(307, 7, 20, 43, 1, 7, 2, 1339760, 312),
(308, 7, 20, 44, 1, 10, 2, 1884930, 580),
(309, 1, 21, 45, 1, 1, 1, 500000, 250),
(310, 2, 22, 46, 1, 8, 2, 250000, 2500);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `bolge`
--

DROP TABLE IF EXISTS `bolge`;
CREATE TABLE IF NOT EXISTS `bolge` (
  `bolge_ad` varchar(20) COLLATE utf8mb4_turkish_ci NOT NULL,
  `bolge_id` int(11) NOT NULL,
  PRIMARY KEY (`bolge_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `bolge`
--

INSERT INTO `bolge` (`bolge_ad`, `bolge_id`) VALUES
('Marmara', 1),
('Karadeniz', 2),
('Ege', 3),
('ic anadolu', 4),
('Akdeniz', 5),
('dogu anadolu', 6),
('guneydogu anadolu', 7);

--
-- Tetikleyiciler `bolge`
--
DROP TRIGGER IF EXISTS `bolge_ismi_buyuk_harf`;
DELIMITER $$
CREATE TRIGGER `bolge_ismi_buyuk_harf` BEFORE INSERT ON `bolge` FOR EACH ROW SET new.bolge_ad=concat(upper(substring(new.bolge_ad,1,1)),lower (substring(new.bolge_ad,2)))
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kullanici`
--

DROP TABLE IF EXISTS `kullanici`;
CREATE TABLE IF NOT EXISTS `kullanici` (
  `username` varchar(50) COLLATE utf8_turkish_ci DEFAULT NULL,
  `password` varchar(50) COLLATE utf8_turkish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `kullanici`
--

INSERT INTO `kullanici` (`username`, `password`) VALUES
('Azd', '12345'),
('Canberk', '123');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `marka`
--

DROP TABLE IF EXISTS `marka`;
CREATE TABLE IF NOT EXISTS `marka` (
  `marka_ad` varchar(20) COLLATE utf8mb4_turkish_ci NOT NULL,
  `marka_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`marka_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `marka`
--

INSERT INTO `marka` (`marka_ad`, `marka_id`) VALUES
('AUDI', 1),
('BMW', 2),
('CHERY', 3),
('CITROEN', 4),
('DACIA', 5),
('FIAT', 6),
('FORD', 7),
('HONDA', 8),
('HYUNDAI', 9),
('KIA', 10),
('MERCEDES-BENZ', 11),
('NISSAN', 12),
('OPEL', 13),
('PEUGEOT', 14),
('RENAULT', 15),
('SEAT', 16),
('SKODA', 17),
('TOYOTA', 18),
('VOLKSWAGEN', 19),
('VOLVO', 20),
('Lamborhgini', 21),
('Porshce', 22);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `model`
--

DROP TABLE IF EXISTS `model`;
CREATE TABLE IF NOT EXISTS `model` (
  `model_ad` varchar(20) COLLATE utf8mb4_turkish_ci NOT NULL,
  `model_id` int(11) NOT NULL AUTO_INCREMENT,
  `marka_id` int(11) NOT NULL,
  PRIMARY KEY (`model_id`),
  KEY `marka_id` (`marka_id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `model`
--

INSERT INTO `model` (`model_ad`, `model_id`, `marka_id`) VALUES
('A3', 1, 1),
('A5', 2, 1),
('3 Serisi', 3, 2),
('5 Serisi', 4, 2),
('Omoda 5', 5, 3),
('Tiggo 7 Pro', 6, 3),
('Tiggo 8 Pro', 7, 3),
('C3 Aircross', 8, 4),
('Ami', 9, 4),
('Berlingo', 10, 4),
('Duster', 11, 5),
('Jogger', 12, 5),
('Sandero', 13, 5),
('Egea', 14, 6),
('Egea Cross', 15, 6),
('Fiorino', 16, 6),
('Focus', 17, 7),
('Courier', 18, 7),
('City', 19, 8),
('Civic', 20, 8),
('i20', 21, 9),
('Stonic', 22, 10),
('Picanto', 23, 10),
('E Serisi', 24, 11),
('CLA', 25, 11),
('Qashqaİ', 26, 12),
('Corsa', 27, 13),
('Astra', 28, 13),
('Combo', 29, 13),
('3008', 30, 14),
('2008', 31, 14),
('Rifter', 32, 14),
('Clio', 33, 15),
('Megane', 34, 15),
('Taliant', 35, 15),
('Express', 36, 15),
('İbiza', 37, 16),
('Superb', 38, 17),
('Corolla', 39, 18),
('T-Roc', 40, 19),
('Caddy', 41, 19),
('Tiguan', 42, 19),
('XC40', 43, 20),
('XC90', 44, 20),
('V30', 45, 21),
('V50', 46, 22);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `motorhacim`
--

DROP TABLE IF EXISTS `motorhacim`;
CREATE TABLE IF NOT EXISTS `motorhacim` (
  `hacim_tur` varchar(20) COLLATE utf8mb4_turkish_ci NOT NULL,
  `hacim_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`hacim_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `motorhacim`
--

INSERT INTO `motorhacim` (`hacim_tur`, `hacim_id`) VALUES
('0.9', 1),
('1.0', 2),
('1.1', 3),
('1.2', 4),
('1.3', 5),
('1.4', 6),
('1.5', 7),
('1.6', 8),
('1.8', 9),
('2.0', 10),
('2.2', 11),
('2.5', 12);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tarz`
--

DROP TABLE IF EXISTS `tarz`;
CREATE TABLE IF NOT EXISTS `tarz` (
  `tarz_ad` varchar(20) COLLATE utf8mb4_turkish_ci NOT NULL,
  `tarz_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`tarz_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `tarz`
--

INSERT INTO `tarz` (`tarz_ad`, `tarz_id`) VALUES
('Binek', 1),
('Hafif Ticari', 2);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `vites`
--

DROP TABLE IF EXISTS `vites`;
CREATE TABLE IF NOT EXISTS `vites` (
  `vites_tur` varchar(20) COLLATE utf8mb4_turkish_ci NOT NULL,
  `vites_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`vites_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

--
-- Tablo döküm verisi `vites`
--

INSERT INTO `vites` (`vites_tur`, `vites_id`) VALUES
('Manuel', 1),
('Otomatik', 2);

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `araclar`
--
ALTER TABLE `araclar`
  ADD CONSTRAINT `araclar_ibfk_1` FOREIGN KEY (`marka_id`) REFERENCES `marka` (`marka_id`),
  ADD CONSTRAINT `araclar_ibfk_2` FOREIGN KEY (`model_id`) REFERENCES `model` (`model_id`),
  ADD CONSTRAINT `araclar_ibfk_3` FOREIGN KEY (`tarz_id`) REFERENCES `tarz` (`tarz_id`),
  ADD CONSTRAINT `araclar_ibfk_4` FOREIGN KEY (`bolge_id`) REFERENCES `bolge` (`bolge_id`),
  ADD CONSTRAINT `araclar_ibfk_5` FOREIGN KEY (`vites_id`) REFERENCES `vites` (`vites_id`),
  ADD CONSTRAINT `araclar_ibfk_6` FOREIGN KEY (`hacim_id`) REFERENCES `motorhacim` (`hacim_id`);

--
-- Tablo kısıtlamaları `model`
--
ALTER TABLE `model`
  ADD CONSTRAINT `model_ibfk_1` FOREIGN KEY (`marka_id`) REFERENCES `marka` (`marka_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
