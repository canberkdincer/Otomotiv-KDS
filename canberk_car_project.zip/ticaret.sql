-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 06 Haz 2021, 18:53:20
-- Sunucu sürümü: 5.7.31
-- PHP Sürümü: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `ticaret`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `gerceklesmeyen_siparis`
--

DROP TABLE IF EXISTS `gerceklesmeyen_siparis`;
CREATE TABLE IF NOT EXISTS `gerceklesmeyen_siparis` (
  `siparis_id` int(11) NOT NULL,
  `toplam_fiyat` float NOT NULL,
  `tarih` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `markalar`
--

DROP TABLE IF EXISTS `markalar`;
CREATE TABLE IF NOT EXISTS `markalar` (
  `marka_id` int(11) NOT NULL AUTO_INCREMENT,
  `ad` varchar(50) NOT NULL,
  PRIMARY KEY (`marka_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `markalar`
--

INSERT INTO `markalar` (`marka_id`, `ad`) VALUES
(1, 'Tommy Hilfiger'),
(2, 'LC Waikiki'),
(3, 'Koton'),
(4, 'Mavi'),
(5, 'Defacto');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `musteriler`
--

DROP TABLE IF EXISTS `musteriler`;
CREATE TABLE IF NOT EXISTS `musteriler` (
  `musteri_id` int(11) NOT NULL AUTO_INCREMENT,
  `ad` varchar(255) NOT NULL,
  `soyad` varchar(255) NOT NULL,
  `sehir_id` int(11) NOT NULL,
  PRIMARY KEY (`musteri_id`),
  KEY `sehir_id` (`sehir_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `musteriler`
--

INSERT INTO `musteriler` (`musteri_id`, `ad`, `soyad`, `sehir_id`) VALUES
(1, 'Süleyman', 'Yılmaz', 35),
(2, 'Zeynep', 'Güzel', 35),
(3, 'Ali', 'Yılmaz', 51),
(4, 'Selçuk', 'Öztürk', 10),
(5, 'Pelin', 'Su', 35),
(6, 'Mehmet', 'Duru', 35),
(7, 'Orhan', 'Eryiğit', 34),
(8, 'Hüseyin', 'Yerli', 7);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sehirler`
--

DROP TABLE IF EXISTS `sehirler`;
CREATE TABLE IF NOT EXISTS `sehirler` (
  `sehir_id` int(11) NOT NULL AUTO_INCREMENT,
  `ad` varchar(255) NOT NULL,
  PRIMARY KEY (`sehir_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `sehirler`
--

INSERT INTO `sehirler` (`sehir_id`, `ad`) VALUES
(6, 'Ankara'),
(7, 'Antalya'),
(10, 'Nevşehir'),
(16, 'Bursa'),
(26, 'Eskişehir'),
(34, 'İstanbul'),
(35, 'İzmir'),
(42, 'Konya'),
(45, 'Manisa'),
(51, 'Niğde');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `siparisler`
--

DROP TABLE IF EXISTS `siparisler`;
CREATE TABLE IF NOT EXISTS `siparisler` (
  `siparis_id` int(11) NOT NULL AUTO_INCREMENT,
  `musteri_id` int(11) NOT NULL,
  `urun_id` int(11) NOT NULL,
  `adet` int(11) NOT NULL,
  PRIMARY KEY (`siparis_id`),
  KEY `musteri_index` (`musteri_id`),
  KEY `urun_id` (`urun_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

--
-- Tetikleyiciler `siparisler`
--
DROP TRIGGER IF EXISTS `soru1`;
DELIMITER $$
CREATE TRIGGER `soru1` AFTER INSERT ON `siparisler` FOR EACH ROW INSERT INTO siparis_detay 
VALUES(new.siparis_id, new.adet*(select urunler.fiyat FROM urunler WHERE urunler.urun_id = new.urun_id),now())
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `soru2`;
DELIMITER $$
CREATE TRIGGER `soru2` AFTER UPDATE ON `siparisler` FOR EACH ROW UPDATE siparis_detay 
SET siparis_id=new.siparis_id, toplam_fiyat=new.adet*(select urunler.fiyat FROM urunler WHERE urunler.urun_id = new.urun_id), tarih=now()
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `soru7`;
DELIMITER $$
CREATE TRIGGER `soru7` BEFORE INSERT ON `siparisler` FOR EACH ROW UPDATE urunler
SET urunler.adet=urunler.adet-new.adet
WHERE urunler.urun_id=new.urun_id
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `soru8`;
DELIMITER $$
CREATE TRIGGER `soru8` BEFORE DELETE ON `siparisler` FOR EACH ROW UPDATE urunler
SET urunler.adet=urunler.adet+old.adet
WHERE urunler.urun_id=old.urun_id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `siparis_detay`
--

DROP TABLE IF EXISTS `siparis_detay`;
CREATE TABLE IF NOT EXISTS `siparis_detay` (
  `siparis_id` int(11) NOT NULL,
  `toplam_fiyat` float NOT NULL,
  `tarih` datetime NOT NULL,
  KEY `siparis_id` (`siparis_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tetikleyiciler `siparis_detay`
--
DROP TRIGGER IF EXISTS `soru3`;
DELIMITER $$
CREATE TRIGGER `soru3` AFTER UPDATE ON `siparis_detay` FOR EACH ROW INSERT INTO gerceklesmeyen_siparis VALUES(old.siparis_id, old.toplam_fiyat, old.tarih)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `urunler`
--

DROP TABLE IF EXISTS `urunler`;
CREATE TABLE IF NOT EXISTS `urunler` (
  `urun_id` int(11) NOT NULL AUTO_INCREMENT,
  `ad` varchar(255) NOT NULL,
  `fiyat` float NOT NULL,
  `marka_id` int(11) NOT NULL,
  `adet` int(11) DEFAULT NULL,
  PRIMARY KEY (`urun_id`),
  KEY `marka_index` (`marka_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `urunler`
--

INSERT INTO `urunler` (`urun_id`, `ad`, `fiyat`, `marka_id`, `adet`) VALUES
(1, 'Gömlek (Erkek)', 150, 1, 50),
(2, 'Gömlek (Bayan)', 175.5, 1, 50),
(3, 'Pantolon (Erkek)', 99.5, 2, 50),
(4, 'Kazak (Bayan)', 139.9, 2, 50),
(5, 'Gömlek (Erkek)', 75.9, 3, 50),
(6, 'Hırka', 69.99, 3, 50),
(7, 'Ceket (Erkek)', 127.5, 4, 50),
(8, 'Kemer (Bayan)', 39.99, 4, 50),
(9, 'Tunik (Bayan)', 89.99, 5, 50),
(10, 'Etek (Bayan)', 115.5, 5, 50);

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `musteriler`
--
ALTER TABLE `musteriler`
  ADD CONSTRAINT `musteri_sehir` FOREIGN KEY (`sehir_id`) REFERENCES `sehirler` (`sehir_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Tablo kısıtlamaları `siparisler`
--
ALTER TABLE `siparisler`
  ADD CONSTRAINT `denememee` FOREIGN KEY (`urun_id`) REFERENCES `urunler` (`urun_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `musteri_siparis` FOREIGN KEY (`musteri_id`) REFERENCES `musteriler` (`musteri_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Tablo kısıtlamaları `siparis_detay`
--
ALTER TABLE `siparis_detay`
  ADD CONSTRAINT `siparis_id` FOREIGN KEY (`siparis_id`) REFERENCES `siparisler` (`siparis_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Tablo kısıtlamaları `urunler`
--
ALTER TABLE `urunler`
  ADD CONSTRAINT `urun_marka` FOREIGN KEY (`marka_id`) REFERENCES `markalar` (`marka_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
