require("dotenv").config({
    path: "../"
})
const { MYSQL_USER, MYSQL_DATABASE, MYSQL_HOST, MYSQL_PASSWORD } = process.env;
const mysql = require("mysql2");
const mysqlPool = mysql.createPool({
    host: MYSQL_HOST,
    user: MYSQL_USER,
    database: MYSQL_DATABASE,
    password: MYSQL_PASSWORD,
    multipleStatements: true
});

mysqlPool.getConnection(async (err, connection) => {
    if (err) throw err;
    console.log(`MySQL veritabanı bağlantısı kuruldu`)
    connection.destroy();
})

function getCarsProperties() {
    return new Promise(async r => {
        mysqlPool.getConnection((err, conn) => {
            if (err) throw err;
            conn.query(`SELECT * FROM motorhacim; SELECT * FROM bolge`, (err, results) => {
                r({
                    motorhacim: results[0],
                    bolge: results[1]
                })
                conn.release();
            });
        })
    })
}

const query = (sqlText, sqlValues) => {
    return new Promise(rs => {
        mysqlPool.getConnection((err, conn) => {
            if (err) throw err;
            conn.query(sqlText, sqlValues, (err, r) => {
                if (err) throw err;
                rs({ r })
                conn.release();
            })
        })
    })
}

function addCar(carData) {
    const { marka, model, bolge_id, vites_tur_id, motor_tur_id, tarz_id, fiyat, satis_adet } = carData;
    return new Promise(async r => {
        const marka_id = (await query(`INSERT INTO marka(marka_ad) VALUES(?)`, [marka])).r.insertId;
        const model_id = (await query(`INSERT INTO model(model_ad, marka_id) VALUES(?, ?)`, [model, marka_id])).r.insertId;

        const result = await query(`INSERT INTO araclar(bolge_id, marka_id, model_id, tarz_id, hacim_id, vites_id, fiyat, satis_adet) VALUES(
            ${["?", "?", "?", "?", "?", "?", "?", "?"].join(", ")}
        )`, [
            bolge_id,
            marka_id,
            model_id,
            tarz_id,
            motor_tur_id,
            vites_tur_id,
            fiyat,
            satis_adet
        ]);
        r({
            message: "Başarıyla eklendi"
        });
    })
}

function getCars() {
    return new Promise(r => {
        mysqlPool.getConnection((err, connection) => {
            connection.query(`SELECT * FROM araclar`, (err, results) => {
                r(results);
                connection.release();
            })
        })
    })
}

function getGraphicsBoxData(bolge) {
    return new Promise(async r => {
        const bolgeAracSayisi = (await getProcedureData(`${bolge}_markalar`)).length;
        const carsData = await Promise.all(Object.values(await getCars()).map(async v => await getCarData(v)));
        const bolgeCars = carsData.filter(v => v.bolge_ad.toLowerCase() === bolge);
        const bolgeFiyatOrt = Math.floor(Array.from(bolgeCars.map(v => v.fiyat * 1)).reduce((a, b) => a + b, 0) / bolgeCars.length);

        r({
            bolgeAracSayisi,
            bolgeFiyatOrt,
            aracTarz: "Binek"
        })
    })
}

function getGraphicsChartData(bolge) {
    return new Promise(async r => {
        const fiyat = (await query(`CALL ${bolge}_fiyat`)).r[0][0];
        const markalar = (await query(`CALL ${bolge}_markalar`)).r[0]
        const model = (await query(`CALL ${bolge}_model`)).r[0];
        const motorhacim = (await query(`CALL ${bolge}_motorhacim`)).r[0];
        const tarz = (await query(`CALL ${bolge}_tarz`)).r[0];
        const vites = (await query(`CALL ${bolge}_vites`)).r[0];

        r({
            fiyat,
            markalar,
            model,
            motorhacim,
            tarz,
            vites
        })
    })
}

function getProcedureData(procedureName) {
    return new Promise(r => {
        mysqlPool.getConnection((err, connection) => {
            connection.query('CALL `' + procedureName + '`()', (err, results) => {
                if (results[0].length > 1) r(results[0])
                else r(results[0][0])
                connection.release();
            })
        })
    })
}

const fastQuery = sqlText => new Promise(r => {
    mysqlPool.getConnection((err, connection) => {
        if (err) throw err;
        connection.query(sqlText, (err, result) => {
            r(result[0])
            connection.release();
        })
    })
})

function getCarData({
    aracSatisID,
    bolge_id,
    marka_id,
    model_id,
    tarz_id,
    hacim_id,
    vites_id,
    fiyat,
    satis_adet
}) {
    return new Promise(async r => {
        let json = { fiyat, satis_adet };
        const bolge_ad = (await fastQuery(`SELECT * FROM bolge WHERE bolge_id = ${bolge_id}`)).bolge_ad,
            marka_ad = (await fastQuery(`SELECT * FROM marka WHERE marka_id = ${marka_id}`)).marka_ad,
            model_ad = (await fastQuery(`SELECT * FROM model WHERE model_id = ${model_id}`)).model_ad,
            motor_hacim = (await fastQuery(`SELECT * FROM motorhacim WHERE hacim_id = ${hacim_id}`)).hacim_tur,
            tarz = (await fastQuery(`SELECT * FROM tarz WHERE tarz_id = ${tarz_id}`)).tarz_ad,
            vites = (await fastQuery(`SELECT * FROM vites WHERE vites_id = ${vites_id}`)).vites_tur;

        r({
            aracSatisID, bolge_ad, marka_ad, model_ad, tarz, motor_hacim, vites, ...json
        });
    })
}



module.exports = { query, getCars, getProcedureData, getGraphicsChartData, getCarData, getCarsProperties, addCar, getGraphicsBoxData }