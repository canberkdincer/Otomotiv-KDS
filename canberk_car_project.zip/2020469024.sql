-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1:3306
-- Üretim Zamanı: 05 May 2023, 01:52:44
-- Sunucu sürümü: 5.7.36
-- PHP Sürümü: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `2020469024`
--

DELIMITER $$
--
-- Yordamlar
--
DROP PROCEDURE IF EXISTS `soru3.1`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.1` (IN `marka` VARCHAR(50), IN `model` VARCHAR(50), IN `yil` INT(4), IN `fiyat` INT(10), IN `id` INT(5))  NO SQL
INSERT INTO `vasita`(`marka`, `model`, `yil`, `fiyat`, `vasita_id`) VALUES (marka, model, yil, fiyat, id)$$

DROP PROCEDURE IF EXISTS `soru3.10`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.10` (IN `yil1` INT(4), IN `yil2` INT(4))  NO SQL
SELECT *
FROM vasita,musteri,satis
WHERE vasita.vasita_id=satis.vasita_id
AND musteri.musteri_id=satis.musteri_id
AND vasita.yil BETWEEN yil1 AND yil2$$

DROP PROCEDURE IF EXISTS `soru3.2`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.2` (IN `marka` VARCHAR(50), IN `model` VARCHAR(50))  NO SQL
DELETE FROM `vasita`
WHERE vasita.marka=marka AND vasita.model=model$$

DROP PROCEDURE IF EXISTS `soru3.3 (ekstra sütun oluşturma)`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.3 (ekstra sütun oluşturma)` ()  NO SQL
ALTER TABLE `vasita` ADD `durum` VARCHAR(50) NULL AFTER `yil`$$

DROP PROCEDURE IF EXISTS `soru3.3 (veri güncelleme)`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.3 (veri güncelleme)` (IN `model_yili` INT(4))  NO SQL
UPDATE vasita
SET vasita.durum='Yeniye Yakın'
WHERE vasita.yil>model_yili$$

DROP PROCEDURE IF EXISTS `soru3.4 (count)`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.4 (count)` (IN `yil` INT(4))  NO SQL
SELECT COUNT(vasita.vasita_id) AS secilen_model_yilindaki_arac_sayisi
FROM vasita
WHERE vasita.yil=yil$$

DROP PROCEDURE IF EXISTS `soru3.4 (sum)`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.4 (sum)` (IN `yil` INT(4))  NO SQL
SELECT SUM(vasita.fiyat) AS secilen_model_yilindaki_araçların_toplam_degeri_tl_cinsinden
FROM vasita
WHERE vasita.yil=yil$$

DROP PROCEDURE IF EXISTS `soru3.5`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.5` (IN `yas` INT(2))  NO SQL
SELECT *,(EXTRACT(YEAR FROM now())-vasita.yil) as arac_yasi
FROM vasita
HAVING arac_yasi<yas$$

DROP PROCEDURE IF EXISTS `soru3.6`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.6` ()  NO SQL
CREATE VIEW uygun_araclar_view
AS
SELECT *
FROM vasita
WHERE vasita.fiyat BETWEEN 200000 AND 500000$$

DROP PROCEDURE IF EXISTS `soru3.7(all)`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.7(all)` (IN `marka` VARCHAR(50))  NO SQL
SELECT *
FROM vasita
WHERE vasita.fiyat>ALL(SELECT vasita.fiyat FROM vasita WHERE vasita.marka=marka)$$

DROP PROCEDURE IF EXISTS `soru3.7(any)`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.7(any)` (IN `yil` INT(4))  NO SQL
SELECT *
FROM vasita
WHERE vasita.fiyat>ANY(SELECT vasita.fiyat FROM vasita WHERE vasita.yil=yil)$$

DROP PROCEDURE IF EXISTS `soru3.8(between)`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.8(between)` (IN `fiyat1` INT(10), IN `fiyat2` INT(10))  NO SQL
SELECT *
FROM vasita
WHERE vasita.fiyat BETWEEN fiyat1 AND fiyat2 
HAVING vasita.fiyat NOT IN ('745000')$$

DROP PROCEDURE IF EXISTS `soru3.9`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `soru3.9` ()  NO SQL
SELECT *
FROM musteri,vasita,satis,personel,sube
WHERE musteri.musteri_id=satis.musteri_id
AND vasita.vasita_id=satis.vasita_id
AND personel.personel_id=satis.personel_id
AND sube.sube_id=satis.sube_id$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `musteri`
--

DROP TABLE IF EXISTS `musteri`;
CREATE TABLE IF NOT EXISTS `musteri` (
  `ad` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `soyad` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `adres` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `telefon` varchar(11) COLLATE utf8_turkish_ci NOT NULL,
  `musteri_id` int(5) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`musteri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `musteri`
--

INSERT INTO `musteri` (`ad`, `soyad`, `adres`, `telefon`, `musteri_id`) VALUES
('Sinan', 'Engin', 'Beşiktaş,İstanbul', '05322415861', 1),
('Enes', 'Alp', 'Zile,Tokat', '05538172860', 2),
('İrem Nur', 'Toklucu', 'Sarıyer,İstanbul', '05347826060', 3),
('Ekrem', 'Güllü', 'Taşköprü,Kastamonu', '05467290675', 4),
('Özge', 'Ertürk', 'Seydişehir,Konya', '05345679821', 5),
('İbrahim', 'Özkan', 'Odunpazarı,Eskişehir', '05443207684', 6),
('Cem', 'Gülfidan', 'Akyaka,Muğla', '05324657638', 7),
('Tuğba', 'Ermiş', 'Sürmene,Trabzon', '05367543261', 8),
('Gülistan', 'Akbulut', 'Artuklu,Mardin', '05423567865', 9),
('İsmail', 'Yurtseven', 'Mitte,Hamm', '05442376539', 10);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `personel`
--

DROP TABLE IF EXISTS `personel`;
CREATE TABLE IF NOT EXISTS `personel` (
  `adi` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `soyadi` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `gorev` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `telefon` varchar(11) COLLATE utf8_turkish_ci NOT NULL,
  `personel_id` int(5) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`personel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `personel`
--

INSERT INTO `personel` (`adi`, `soyadi`, `gorev`, `telefon`, `personel_id`) VALUES
('Özcan', 'Çolak', 'Müdür', '05424217864', 1),
('Elif', 'Karabulut', 'Finans Uzmanı', '05328745698', 2),
('Sezer', 'Karagöz', 'Finans Uzmanı Yardımcısı', '05368924040', 3),
('Nisa', 'Saklı', 'İnsan Kaynakları Uzmanı', '05334665787', 4),
('Uğur', 'Göveli', 'Satış Danışmanı', '05423253454', 5),
('Ali', 'Güler', 'Servis Danışmanı', '05345689800', 6),
('Engin', 'Sevinç', 'Yıkama Görevlisi', '05418908174', 7),
('Osman', 'Hünerci', 'Teknisyen', '05427550554', 8),
('Şahin', 'Şentürk', 'Satış Danışmanı', '05356457621', 9),
('Yücel', 'Arslan', 'Teknisyen', '05326794506', 10),
('Serap', 'Yılmaz', 'Satış Danışmanı', '05446857698', 11);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `satis`
--

DROP TABLE IF EXISTS `satis`;
CREATE TABLE IF NOT EXISTS `satis` (
  `tarih` date NOT NULL,
  `vasita_id` int(5) NOT NULL,
  `musteri_id` int(5) NOT NULL,
  `personel_id` int(5) NOT NULL,
  `sube_id` int(5) NOT NULL,
  `satis_id` int(5) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`satis_id`),
  KEY `sube_id` (`sube_id`),
  KEY `vasita_id` (`vasita_id`,`musteri_id`,`personel_id`),
  KEY `musteri_id` (`musteri_id`),
  KEY `personel_id` (`personel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `satis`
--

INSERT INTO `satis` (`tarih`, `vasita_id`, `musteri_id`, `personel_id`, `sube_id`, `satis_id`) VALUES
('2022-10-02', 9, 6, 5, 1, 1),
('2022-10-15', 15, 10, 11, 1, 2),
('2022-09-17', 4, 7, 9, 1, 3),
('2022-07-24', 10, 4, 5, 1, 4),
('2022-11-29', 6, 5, 9, 1, 5),
('2022-11-29', 1, 8, 11, 1, 6),
('2022-12-13', 19, 3, 11, 1, 7),
('2023-01-19', 14, 2, 5, 1, 8),
('2023-02-22', 11, 9, 11, 1, 9),
('2023-04-07', 18, 1, 11, 1, 10);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sube`
--

DROP TABLE IF EXISTS `sube`;
CREATE TABLE IF NOT EXISTS `sube` (
  `adres` varchar(250) COLLATE utf8_turkish_ci NOT NULL,
  `telefon` varchar(11) COLLATE utf8_turkish_ci NOT NULL,
  `sube_id` int(5) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`sube_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `sube`
--

INSERT INTO `sube` (`adres`, `telefon`, `sube_id`) VALUES
('Tuzla,İstanbul', '02165423434', 1);

-- --------------------------------------------------------

--
-- Görünüm yapısı durumu `uygun_araclar_view`
-- (Asıl görünüm için aşağıya bakın)
--
DROP VIEW IF EXISTS `uygun_araclar_view`;
CREATE TABLE IF NOT EXISTS `uygun_araclar_view` (
`marka` varchar(50)
,`model` varchar(50)
,`yil` int(4)
,`fiyat` int(10)
,`vasita_id` int(5)
);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `vasita`
--

DROP TABLE IF EXISTS `vasita`;
CREATE TABLE IF NOT EXISTS `vasita` (
  `marka` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `model` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `yil` int(4) NOT NULL,
  `fiyat` int(10) NOT NULL,
  `vasita_id` int(5) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`vasita_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `vasita`
--

INSERT INTO `vasita` (`marka`, `model`, `yil`, `fiyat`, `vasita_id`) VALUES
('Alfa Romeo', 'Giulietta', 2015, 575000, 1),
('Chevrolet', 'Cruze', 2012, 450000, 2),
('Daihatsu', 'Sirion', 2005, 275000, 3),
('Ford', 'Mondeo', 2012, 500000, 4),
('Geely', 'Emgrand', 2013, 315000, 5),
('Hyundai', 'Elantra', 2017, 745000, 6),
('Mazda', 'Lantis', 1997, 215000, 7),
('Nissan', 'Micra', 2010, 450000, 8),
('Renault', 'Fluence', 2014, 450000, 9),
('Toyota', 'Corolla', 2021, 960000, 10),
('Citroen', 'C-Elysee', 2019, 490000, 11),
('Ferrari', 'California', 2012, 8800000, 12),
('Jaguar', 'S-Type', 2001, 390000, 13),
('Leapmotor', 'T03', 2022, 620000, 14),
('Lamborghini', 'Huracan', 2014, 15100000, 15),
('Mini', 'Cooper', 2017, 850000, 16),
('Volvo', 'S90', 2022, 3600000, 17),
('Volkswagen', 'Passat Variant', 2020, 1455000, 18),
('Seat', 'Leon', 2020, 1030000, 19),
('Opel', 'Astra', 2009, 439000, 20);

-- --------------------------------------------------------

--
-- Görünüm yapısı `uygun_araclar_view`
--
DROP TABLE IF EXISTS `uygun_araclar_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `uygun_araclar_view`  AS SELECT `vasita`.`marka` AS `marka`, `vasita`.`model` AS `model`, `vasita`.`yil` AS `yil`, `vasita`.`fiyat` AS `fiyat`, `vasita`.`vasita_id` AS `vasita_id` FROM `vasita` WHERE (`vasita`.`fiyat` between 200000 and 500000) ;

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `satis`
--
ALTER TABLE `satis`
  ADD CONSTRAINT `satis_ibfk_1` FOREIGN KEY (`musteri_id`) REFERENCES `musteri` (`musteri_id`),
  ADD CONSTRAINT `satis_ibfk_2` FOREIGN KEY (`vasita_id`) REFERENCES `vasita` (`vasita_id`),
  ADD CONSTRAINT `satis_ibfk_3` FOREIGN KEY (`personel_id`) REFERENCES `personel` (`personel_id`),
  ADD CONSTRAINT `satis_ibfk_4` FOREIGN KEY (`sube_id`) REFERENCES `sube` (`sube_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
