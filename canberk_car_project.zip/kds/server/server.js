require("dotenv").config();
const express = require("express");
const app = express();
const path = require("path");
const { getCars, getCarData, getProcedureData, getCarsProperties, addCar, getGraphicsBoxData, query, getGraphicsChartData } = require("./database/MySQLDatabase")

app.use(express.urlencoded({ extended: false }));

app.use(require("express-session")({
    secret: "secret",
    saveUninitialized: false,
    resave: true
}))

app.use(require("cookie-parser")())

const { PORT } = process.env;

const procedureBolgeler = [
    "akdeniz",
    "dogu_anadolu",
    "ege",
    "guneydogu_anadolu",
    "ic_anadolu",
    "karadeniz",
    "marmara"
];

const procedureCarProps = [
    "fiyat",
    "markalar",
    "model",
    "motorhacim",
    "tarz",
    "vites"
];

app.use("/dist", express.static(path.join(__dirname, "../client/dist")));

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "../client/views"));

app.get("/login", (req, res) => {
    res.render("login")
})

app.get("/register", (req, res) => {
    res.render("register")
})

app.post("/register", async (req, res) => {
    const { username, password } = req.body;
    const result = await query(`INSERT INTO kullanici(username, password) VALUES(?,?)`, [username, password]);
    if (result) res.redirect("/login")
})

app.post("/login", async (req, res) => {
    const { username, password } = req.body;
    const result = (await query(`SELECT * FROM kullanici WHERE username = ?`, [username])).r[0];
    if (typeof result === 'undefined') return res.json({
        message: "Kullanıcı bulunamadı"
    });
    if (result.password === password) {
        req.session.auth = true;
        req.session.user = req.body;
        res.redirect("/");
    }
})

app.post("/api/add_car", express.json(), async (req, res) => {
    res.json(await addCar(req.body));
})

app.get(["/", "/tablolar"], async (req, res) => {
    if(!req.session?.auth) return res.render("login");
    const carsData = await Promise.all(Object.values(await getCars()).map(async v => await getCarData(v)));
    const carProps = await getCarsProperties();
    res.render("DataViews", { carsData, carProps, procedureCarProps, procedureBolgeler })
})

app.get("/veri_girisi", async (req, res) => {
    if(!req.session?.auth) return res.render("login");
    const carProps = await getCarsProperties();
    res.render("DataInput", { carProps });
})

app.get("/grafikler", async (req, res) => {
    if(!req.session?.auth) return res.render("login");
    res.render("Graphics", { procedureBolgeler })
})

app.get("/api/graphicsData", async (req, res) => {
    const { type, bolge } = req.query;

    if (type === "box") {
        res.json(await getGraphicsBoxData(bolge));
    } else if (type === "charts") {
        res.json(await getGraphicsChartData(bolge));
    }
})

app.get("/api/procedures", async (req, res) => {
    const { bolge, prop } = req.query;

    if (procedureBolgeler.includes(bolge) && procedureCarProps.includes(prop)) {
        const procedureData = await getProcedureData(`${bolge}_${prop}`);
        if (procedureData) res.json(procedureData);
        return;
    }
    res.status(403).json({
        error: true,
        message: "Invalid proecedure name"
    })
})

app.listen(PORT, () => console.log(`Server listening on ${PORT}`));